import HtmlParser from 'html-react-parser'
import Layout from '@/components/common/Layout'
import Ad from '@/components/molecules/Ad'
import ExploreAnalytics from '@/components/organisms/ExploreAnalytics'
import FeaturedGrid from '@/components/organisms/FeaturedGrid'
import HomeHero from '@/components/organisms/HomeHero'
import PostsLatest from '@/components/organisms/PostsLatest'

export default function HomePage({
  page,
  primaryPost,
  latestPosts,
  featuredInsights,
}) {
  const { yoast_head } = page

  function getRandomInt(max) {
    return Math.floor(Math.random() * max)
  }
  let sponsoredLatestPosts = latestPosts.filter(
    (post) => post.acf.pin_sponsored_post === '1'
  )
  if (sponsoredLatestPosts && sponsoredLatestPosts.length >= 1) {
    let sponsoredItems = sponsoredLatestPosts.length
    let randomsponsoredItem = getRandomInt(sponsoredItems)
    let choosenSponsoredItem = sponsoredLatestPosts[randomsponsoredItem]
    latestPosts = latestPosts.filter(
      (post) => post.id !== choosenSponsoredItem.id
    )
    latestPosts[2] = choosenSponsoredItem
  }
  let latestPostsA = latestPosts.slice(0, 5)
  let latestPostsB = latestPosts.slice(5, 10)

  let pinnedfeaturedInsights = featuredInsights.filter(
    (post) => post.acf.home_featured_grid === '1'
  )
  if (pinnedfeaturedInsights && pinnedfeaturedInsights.length >= 1) {
    //should be 3 or less
    let pinLen = pinnedfeaturedInsights.length
    if (pinLen !== 0) {
      let openSpots = 4 - pinLen
      //need to remove any pinnedfeaturedInsights, from featureinsight
      featuredInsights = featuredInsights.filter((e) =>
        pinnedfeaturedInsights.indexOf(e) > -1 ? false : true
      )
      featuredInsights = featuredInsights.slice(0, openSpots)
      featuredInsights = pinnedfeaturedInsights.concat(featuredInsights)
    }
  } else {
    featuredInsights.slice(0, 4)
  }

  return (
    <Layout seo={HtmlParser(yoast_head)}>
      <HomeHero primaryPost={primaryPost} heroNews={latestPostsA} />

      <Ad
        ad_image={page.acf?.ad_top?.ad_image}
        ad_link={page.acf?.ad_top?.ad_link}
        classes={page.acf?.ad_top?.ad_tracking_classes}
      />

      <ExploreAnalytics />

      <FeaturedGrid posts={featuredInsights} type='insight' />

      <Ad
        ad_image={page.acf?.ad_mid?.ad_image}
        ad_link={page.acf?.ad_mid?.ad_link}
        classes={page.acf?.ad_mid?.ad_tracking_classes}
      />

      <PostsLatest
        page={page}
        posts={latestPostsB}
        type='news'
        linkTitle='Read News'
      />
    </Layout>
  )
}

export async function getStaticProps() {
  /**
   * Page Content
   */
  const PAGE_ID = 5
  const res = await fetch(
    `https://dhix.dhinsights.org/wp-json/wp/v2/pages/${PAGE_ID}`
  )
  const page = await res.json()

  /**
   * Primary Post
   */
  const POST_PRIMARY = page.acf?.featured_article
    ? page.acf?.featured_article
    : '750'
  const primaryPostRes = await fetch(
    `https://dhix.dhinsights.org/wp-json/wp/v2/posts/${POST_PRIMARY}`
  )
  const primaryPost = await primaryPostRes.json()

  /**
   * Recent News
   */
  const SPONSORED_CATEGORY = 233
  const latestPostsRes = await fetch(
    `https://dhix.dhinsights.org/wp-json/wp/v2/posts?filter[orderby]=date&order=desc&exclude=${POST_PRIMARY}`
  )
  const latestPosts = await latestPostsRes.json()

  await Promise.all(
    latestPosts.map(async (element) => {
      if (element.categories.length > 1) {
        element.categories.forEach((cat) => {
          if (cat === SPONSORED_CATEGORY) {
            element.categories[0] = SPONSORED_CATEGORY
          }
        })
      }

      const getCategory = await fetch(
        `https://dhix.dhinsights.org/wp-json/wp/v2/categories/${element.categories[0]}`
      )
      const cat = await getCategory.json()
      element.categoryName = cat.name
    })
  )

  /**
   * Featured Insights
   */

  // pull in webinar results and merge json
  const TOPIC_FEATURED = 45
  const TYPE_WHITEPAPER = 190
  const TYPE_WEBINAR = 19

  const featuredNewsWhitePaperRes = await fetch(
    `https://dhix.dhinsights.org/wp-json/wp/v2/insight?topic=${TOPIC_FEATURED}&insight_type=${TYPE_WHITEPAPER}&exclude=${POST_PRIMARY}`
  )
  const featuredInsightsWhitePaper = await featuredNewsWhitePaperRes.json()

  const featuredNewsWebinarRes = await fetch(
    `https://dhix.dhinsights.org/wp-json/wp/v2/insight?topic=${TOPIC_FEATURED}&insight_type=${TYPE_WEBINAR}&exclude=${POST_PRIMARY}`
  )
  const featuredInsightsWebinar = await featuredNewsWebinarRes.json()

  const featuredInsights = featuredInsightsWhitePaper.concat(
    featuredInsightsWebinar
  )

  return {
    props: {
      page,
      primaryPost,
      latestPosts: latestPosts,
      featuredInsights: featuredInsights,
    },
    revalidate: 10,
  }
}
