export { default } from './FooterSocial'
