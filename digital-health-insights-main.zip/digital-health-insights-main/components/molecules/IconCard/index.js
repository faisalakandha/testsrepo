export { default } from './IconCard'
