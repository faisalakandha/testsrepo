export { default } from './ReportsResults'
