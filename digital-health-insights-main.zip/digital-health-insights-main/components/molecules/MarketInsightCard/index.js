export { default } from './MarketInsightCard'
