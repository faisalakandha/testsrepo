export { default } from './PortalFooterMenu'
