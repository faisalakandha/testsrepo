export { default } from './MarketInsightRecommendationCard'
