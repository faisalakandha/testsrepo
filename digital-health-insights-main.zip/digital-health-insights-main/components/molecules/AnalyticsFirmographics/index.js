export { default } from './AnalyticsFirmographics'
