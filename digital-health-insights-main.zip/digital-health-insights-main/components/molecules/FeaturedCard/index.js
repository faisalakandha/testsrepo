export { default } from './FeaturedCard'
