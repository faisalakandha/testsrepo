export { default } from './SearchCard'
