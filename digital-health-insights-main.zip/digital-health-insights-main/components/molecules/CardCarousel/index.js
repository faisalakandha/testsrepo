export { default } from './CardCarousel'
