export { default } from './Ad'
