export { default } from './SponsoredBy'
