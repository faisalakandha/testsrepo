export { default } from './DoughnutChart'
