export { default } from './Image'
