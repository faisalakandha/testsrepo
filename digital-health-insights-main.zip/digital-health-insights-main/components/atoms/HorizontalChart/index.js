export { default } from './HorizontalChart'
