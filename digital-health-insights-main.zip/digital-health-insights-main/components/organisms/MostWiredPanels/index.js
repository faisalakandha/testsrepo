export { default } from './MostWiredPanels'
