export { default } from './PostsLatest'
