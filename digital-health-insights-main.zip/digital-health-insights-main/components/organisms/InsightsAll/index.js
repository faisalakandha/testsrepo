export { default } from './InsightsAll'
