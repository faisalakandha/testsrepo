export { default } from './PostBody'
