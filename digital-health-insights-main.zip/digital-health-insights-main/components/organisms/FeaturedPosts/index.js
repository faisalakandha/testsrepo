export { default } from './FeaturedPosts'
