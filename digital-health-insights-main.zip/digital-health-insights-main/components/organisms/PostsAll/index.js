export { default } from './PostsAll'
