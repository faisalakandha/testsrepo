export { default } from './TwoColumnHero'
