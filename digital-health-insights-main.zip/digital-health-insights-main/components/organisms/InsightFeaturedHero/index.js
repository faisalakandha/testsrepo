export { default } from './InsightFeaturedHero'
