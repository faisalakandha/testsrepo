export { default } from './MarketInsightsAll'
