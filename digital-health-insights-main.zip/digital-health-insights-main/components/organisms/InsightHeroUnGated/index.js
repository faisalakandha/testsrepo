export { default } from './InsightHeroUnGated'
