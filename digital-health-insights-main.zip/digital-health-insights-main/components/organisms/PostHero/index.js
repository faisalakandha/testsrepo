export { default } from './PostHero'
