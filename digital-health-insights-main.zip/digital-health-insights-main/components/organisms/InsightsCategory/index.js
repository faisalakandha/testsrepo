export { default } from './InsightsCategory'
