export { default } from './EventRegistration'
