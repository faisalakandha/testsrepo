export { default } from './MostWiredHero'
