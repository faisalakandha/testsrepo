export { default } from './MostWiredTrends'
