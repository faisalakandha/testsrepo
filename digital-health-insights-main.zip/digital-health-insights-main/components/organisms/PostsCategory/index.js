export { default } from './PostsCategory'
