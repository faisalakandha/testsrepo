export { default } from './InsightHero'
