export { default } from './PortalFAQ'
