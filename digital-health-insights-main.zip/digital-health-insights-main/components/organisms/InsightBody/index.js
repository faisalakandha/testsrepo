export { default } from './InsightBody'
