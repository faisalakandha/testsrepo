export { default } from './MostWiredBottom'
