export { default } from './FeaturedGrid'
