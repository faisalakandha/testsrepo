export { default } from './MarketInsightTopic'
