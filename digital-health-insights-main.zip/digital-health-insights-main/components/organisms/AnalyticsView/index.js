export { default } from './AnalyticsView'
